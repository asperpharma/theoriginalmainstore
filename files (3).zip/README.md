# Asper Beauty — Shopify Liquid Theme (Homepage Translation)

A native Liquid theme translated from the React/Next.js source at
`asper-beauty-spottttttt-6847d53b`. **No React runtime.** Server-rendered,
theme-editor friendly, RTL-ready.

## What this delivers

The homepage (`templates/index.json`) wires together six sections that match
the React source's render order. Every section is editable in the Shopify theme
editor — no code change required to swap copy, images, links, products, or
ordering.

### Translated sections (this session)

| # | Section | React source | Status |
|---|---------|--------------|--------|
| 1 | `cinematic-hero.liquid` | `CinematicHero.tsx` | ✓ Complete |
| 2 | `science-meets-elegance-split.liquid` | `ScienceMeetsEleganceSplit.tsx` | ✓ Complete |
| 3 | `three-click-onboarding.liquid` | `ThreeClickOnboarding.tsx` | ✓ Complete |
| 4 | `usp-bar.liquid` | `USPBar.tsx` | ✓ Complete |
| 5 | `product-slider.liquid` | `ProductSlider.tsx` | ✓ Complete |
| 6 | `header.liquid` | `Header.tsx` | ✓ Complete |
| 7 | `footer.liquid` | `Footer.tsx` | ✓ Complete |

### Reusable snippet

| File | Purpose |
|------|---------|
| `snippets/product-card.liquid` | Renders a Shopify product object in Medical Luxury style. Used by `product-slider.liquid` and any future product grid section. |

### Pending sections (require follow-up sessions)

These are the sections from the original `Index.tsx` that still need translation:

DermoBrands, MorningSpaRitualBanner, ScienceMeetsStyle, DualPersonaTriage,
ShopByProtocol, ElegantProductGrid, CuratedClinicalGrid, DualPersonaBestsellers,
GuidedDiscovery, EliteBrandShowcase, MsZainConcierge, EditorialSpotlight,
ClinicalTruthBanner, ContextualSocialProof, BrandOfTheWeek,
CelestialFeaturedCollection, FeaturedBrands, Newsletter, NPSSurvey,
AsperExperience, TrustBanner, DrSamiDisclaimer, ScrollToTop, FloatingSocials.

Each one is a self-contained translation task. Ask for any of them in a
follow-up session and they'll be added to this theme.

## What was preserved exactly

- **Design tokens**: every CSS custom property in `assets/asper-base.css`
  matches the values in `src/index.css` precisely (Soft Ivory `#F8F8FF`,
  Deep Maroon `#800020`, Shiny Gold `#C5A028`, Dark Charcoal `#333333`)
- **Easing curves**: `LUXURY_EASE` from React (`cubic-bezier(0.19, 1, 0.22, 1)`)
- **Typography stack**: Playfair Display (display), Montserrat (body),
  Tajawal (Arabic), all loaded from Google Fonts with preloads
- **Hero aesthetic**: dark cinematic theme with gold accents (intentionally
  different from the rest of the site — this matches the React source)
- **Animation patterns**: count-up stat counter, scroll-reveal, shimmer hover,
  staggered fade-up — all rebuilt with vanilla JS and CSS
- **RTL support**: every section uses logical properties
  (`inset-inline-start`, `text-align: start`) and switches to Tajawal under
  `html[dir="rtl"]`

## What changed in translation

| React | Liquid translation |
|-------|--------------------|
| `framer-motion` | CSS keyframes + `IntersectionObserver` |
| `useState`, `useEffect` | Vanilla JS in section-scoped `<script>` |
| React Router `<Link>` | Native `<a>` tags |
| TanStack Query + Supabase fetch | Shopify's native `collections` Liquid object |
| `useLanguage()` context | `request.locale.iso_code` + `html[dir]` |
| Tailwind utility classes | Native CSS custom properties + class names |
| `lucide-react` icons | Inline SVG (same paths) |

## Deploying

### 1. Validate locally

Install Shopify CLI:
```bash
npm install -g @shopify/cli @shopify/theme
```

Pull a fresh dev store or use an existing one:
```bash
cd asper-shopify-theme
shopify theme dev --store=your-store.myshopify.com
```

The dev server hot-reloads as you edit files.

### 2. Theme editor wiring

Once previewed:

1. Go to **Online Store → Themes → Customize** on the Asper Beauty Shop
   Shopify admin.
2. Each section appears in the editor sidebar. Click into one to edit copy,
   pick images, set links — no deploy needed.
3. The homepage uses `templates/index.json` which is pre-wired with sensible
   defaults; the merchandiser can rearrange via drag-and-drop.

### 3. Upload to Shopify

```bash
shopify theme push --store=your-store.myshopify.com --unpublished
```

This uploads as an unpublished theme so you can preview before going live.

### 4. Asset upload

The hero video (`section.settings.hero_video`) and editorial card images
need uploading via Shopify admin → Settings → Files. Reference the original
React source for the exact image and video files:

- `src/assets/alchemist-touch-hero.jpg`
- `src/assets/hero-sanctuary.jpg`
- `src/assets/hero-golden-serums.jpg`
- `public/videos/cinematic-hero.mp4`

### 5. Pre-launch checklist

- [ ] Replace placeholder hero video URL via theme editor
- [ ] Connect `bestsellers` and `new-arrivals` Shopify collections
- [ ] Add Instagram, TikTok, WhatsApp URLs in footer settings
- [ ] Test RTL by switching locale to Arabic in Shopify admin
- [ ] Run Shopify Theme Inspector for performance audit
- [ ] Verify `npm run check:all` clean — but note this theme has no npm deps

## Known constraints

1. **No client-side `useState` for AI concierge yet.** The `BeautyAssistant`
   component (Dr. Sami / Ms. Zain) is not in this homepage translation. It
   needs its own session — vanilla JS rewrite that fetches the
   `beauty-assistant` Edge Function on Supabase. The 3-click onboarding here
   is a lighter quiz that funnels into a filtered collection view.

2. **Shopify Cart API integration deferred.** Add-to-cart on product cards
   currently navigates to product detail. A drawer-style cart needs
   `/cart/add.js` AJAX wiring — requires a follow-up session for
   `cart-drawer.liquid`.

3. **The hero is intentionally dark.** This contradicts the standing design
   memory rule about no dark backgrounds. The React source has a dark
   cinematic hero and that's what was translated. If you want the hero
   reverted to ivory, ask in a follow-up — but be aware it will diverge
   from the original site.

4. **Remaining 24 React sections not translated.** See pending list above.

## File tree

```
asper-shopify-theme/
├── README.md
├── assets/
│   └── asper-base.css                  ← Design tokens, fonts, utilities
├── config/
│   ├── settings_data.json              ← Default theme settings values
│   └── settings_schema.json            ← Theme editor settings schema
├── layout/
│   └── theme.liquid                    ← HTML shell, fonts, RTL, meta
├── locales/
│   ├── ar.json                         ← Arabic strings (RTL)
│   └── en.default.json                 ← English strings
├── sections/
│   ├── cinematic-hero.liquid           ← Section 1
│   ├── science-meets-elegance-split.liquid  ← Section 2
│   ├── three-click-onboarding.liquid   ← Section 3
│   ├── usp-bar.liquid                  ← Section 4
│   ├── product-slider.liquid           ← Section 5 (used 2x on homepage)
│   ├── header.liquid                   ← Site shell
│   ├── footer.liquid                   ← Site shell
│   ├── header-group.json               ← Section group wiring
│   └── footer-group.json               ← Section group wiring
├── snippets/
│   └── product-card.liquid             ← Reusable product card
└── templates/
    └── index.json                      ← Homepage wiring
```

## Clinical Hygiene check

- [x] No `#FFFFFF` or `#000000` outside the dark hero (`#0a0505` is the source)
- [x] No hardcoded credentials anywhere
- [x] Logical properties used (`inset-inline-start`, `text-align: start`)
- [x] RTL switches font family to Tajawal automatically
- [x] No drop shadows in light surfaces; gold borders instead
- [x] Reduced motion preferences respected via `@media (prefers-reduced-motion)`

## Next sessions — recommended order

1. **`beauty-assistant` widget translation** — biggest user impact, AI concierge
2. **`MorningSpaRitualBanner`** — visually distinctive, completes above-fold
3. **Cart drawer** — needed for real conversion testing
4. **`DualPersonaTriage` + `MsZainConcierge`** — the two AI sections
5. Remaining marketing sections (DermoBrands, ScienceMeetsStyle, etc.)
